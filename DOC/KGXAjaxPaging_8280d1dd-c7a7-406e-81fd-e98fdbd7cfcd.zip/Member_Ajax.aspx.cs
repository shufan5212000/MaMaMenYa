﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Script.Serialization;

namespace JQueryWeb
{
	public partial class Member_Ajax : System.Web.UI.Page
	{
		protected void Page_Load(object sender, EventArgs e)
		{
			Response.Write(GetAll());
		}

		private string GetAll()
		{
			List<Student> list = new List<Student>();

			for (int i = 0; i < 100; i++)
			{
				list.Add(new Student { Id = i, Name = "Name" + i, Age = i });
			}

			int pageIndex = GetPage();
			int pageSize = StrToInt(QueryString("pagesize"), 10); ;
			JavaScriptSerializer javascriptSerializer = new JavaScriptSerializer();

			string result = javascriptSerializer.Serialize(list.Skip(pageSize * (pageIndex - 1)).Take(pageSize).ToList());
			string response = "{\"result\" :\"1\"," +
				"\"returnval\" :\"操作成功\"," +
				"\"pagebar\" :\"" + PageBar.GetPageBar(3, "js", 2, list.Count, pageSize, pageIndex, "javascript:ajaxList(<#page#>);") + "\"," +
			   "\"" + "totalCountStr" + "\":" + 10 + ",\"" + "table" + "\":" + result +
				"}";
			return response;
		}

		private static int GetPage()
		{
			int page = StrToInt(QueryString("pageIndex"), 0) < 1 ? 1 : StrToInt(QueryString("pageIndex"), 0);
			return page;
		}

		private static int StrToInt(string value, int defaultValue)
		{
			if (IsNumeric(value))
				return int.Parse(value);
			else
				return defaultValue;
		}

		/// <summary>
		/// 获取querystring
		/// </summary>
		/// <param name="s">参数名</param>
		/// <returns>返回值</returns>
		private static string QueryString(string s)
		{
			if (HttpContext.Current.Request.QueryString[s] != null && HttpContext.Current.Request.QueryString[s] != "")
			{
				return SafetyQueryS(HttpContext.Current.Request.QueryString[s].ToString());
			}
			return string.Empty;
		}

		/// <summary>
		/// 将字符串中的一些标签过滤
		/// </summary>
		/// <param name="theString"></param>
		/// <returns></returns>
		private static string SafetyQueryS(string theString)
		{
			string[] aryReg = { "'", ";", "\"", "\r", "\n", "<", ">" };
			for (int i = 0; i < aryReg.Length; i++)
			{
				theString = theString.Replace(aryReg[i], string.Empty);
			}
			return theString;
		}

		private static bool IsNumeric(string value)
		{
			System.Text.RegularExpressions.Regex myRegex = new System.Text.RegularExpressions.Regex("^[-]?[1-9]*[0-9]*$");
			if (value.Length == 0)
			{
				return false;
			}
			return myRegex.IsMatch(value);
		}
	}
}