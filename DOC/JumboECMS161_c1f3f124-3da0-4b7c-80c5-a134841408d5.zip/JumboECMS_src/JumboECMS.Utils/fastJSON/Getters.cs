﻿using System;

namespace JumboECMS.Utils.fastJSON
{
    internal class Getters
    {
        public string Name;
        public JSON.GenericGetter Getter;
    }
}
