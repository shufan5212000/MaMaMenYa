﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: System.Diagnostics.Debuggable(System.Diagnostics.DebuggableAttribute.DebuggingModes.DisableOptimizations | System.Diagnostics.DebuggableAttribute.DebuggingModes.EnableEditAndContinue | System.Diagnostics.DebuggableAttribute.DebuggingModes.IgnoreSymbolStoreSequencePoints | System.Diagnostics.DebuggableAttribute.DebuggingModes.Default)]
[assembly: RuntimeCompatibility(WrapNonExceptionThrows=true)]
[assembly: CompilationRelaxations(8)]
[assembly: System.Web.UI.TagPrefix("JumboECMS.WebControls", "Jumboe")]
[assembly: AssemblyTitle("JumboECMS.WebControls")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("将博开发团队")]
[assembly: AssemblyProduct("JumboECMS.WebControls")]
[assembly: AssemblyCopyright("")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: AssemblyVersion("1.6.1.0204")]

[assembly: System.Web.UI.WebResource("JumboECMS.WebControls.FlashFileUpload.swf", "application/x-shockwave-flash")]
[assembly: System.Web.UI.WebResource("JumboECMS.WebControls.expressInstall.swf", "application/x-shockwave-flash")]
[assembly: System.Web.UI.WebResource("JumboECMS.WebControls.swfobject.js", "text/javascript")]


