﻿/*****************************************************
 * 本类库的核心系 AderTemplates
 * (C) Andrew Deren 2004
 * http://www.adersoftware.com
 *****************************************************/

#region Using directives

using System;
using System.Collections.Generic;
using System.Text;

#endregion

namespace JumboECMS.TEngine.Parser.AST
{
	public abstract class Expression : Element
	{
		public Expression(int line, int col)
			:base(line, col)
		{

		}
	}
}
