﻿/*JumboECMS作者申明
 * 该项目已经在原来的开源项目Ader TemplateEngine上改动，为避免冲突，特此更改了项目名
 */
using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyTitle("Ader TemplateEngine开源项目修改版")]
[assembly: AssemblyDescription("该项目已经在原来的开源项目Ader TemplateEngine上改动，为避免冲突，特此更改了项目名")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("将博开发团队")]
[assembly: AssemblyProduct("JumboECMS.TEngine")]
[assembly: AssemblyCopyright("JumboECMS.Net (C) 2011-2014")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: AssemblyVersion("1.6.1.0204")]
