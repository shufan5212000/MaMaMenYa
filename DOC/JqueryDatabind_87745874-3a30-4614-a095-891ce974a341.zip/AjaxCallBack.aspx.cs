﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Text;
using System.Data.OleDb;
using System.Web.SessionState;
using System.Web.Security;
using System.Text.RegularExpressions;
using System.Configuration;
using System.Data.SqlClient;

public partial class AjaxCallBack : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string methodName = Request["act"];
        AjaxMethod al = new AjaxMethod();
        System.Reflection.MethodInfo method = typeof(AjaxMethod).GetMethod(methodName);
        string msg = method.Invoke(al, null).ToString();
        Response.Write(msg);
    }

    public class AjaxMethod : IRequiresSessionState
    {
        HttpContext context;
        public AjaxMethod()
        {
            //为当前http请求获取httpcontext对象
            context = HttpContext.Current;
        }
      
        public string GetMsgList()
        {
            //pageindex:pageindex,pagesize:pagesize
            string sql = "";
            int pageindex = Convert.ToInt32(context.Request["pageindex"]);
            int pagesize = Convert.ToInt32(context.Request["pagesize"]);
            if (pageindex < 1)
            {
                pageindex = 1;
            }
            if (pageindex == 1)
            {
                sql = @"select top " + pagesize + " * from RuncecapeOther order by id asc";
            }
            else
            {
                sql = "select top " + pagesize + " * from RuncecapeOther where id not in(select top " + ((pageindex - 1) * pagesize) + " id  from RuncecapeOther order by id asc) order by id asc";
            }
            StringBuilder sb = new StringBuilder();
            DataTable dt = AccessDB.GetDataSet(sql, CommandType.Text, AccessDB.ConnectionString);
            if (dt.Rows.Count > 0)
            {
                sb.Append("{rows:[");
                int num=0;
                foreach (DataRow row in dt.Rows)
                {
                    num++;
                    if (row["item_name"].ToString().Contains("'"))
                    {
                        row["item_name"] = row["item_name"].ToString().Replace("'", "’");  
                    }
                    if (num == dt.Rows.Count)
                    {
                        sb.Append("{'id':'" + row["id"] + "','game_id':'" + row["game_id"] + "','item_name':'" + row["item_name"] + "','price':'" + row["price"] + "','parent_type':'" + row["parent_type"] + "','item_type':'" + row["item_type"] + "'}");
                    }
                    else
                    {
                        sb.Append("{'id':'" + row["id"] + "','game_id':'" + row["game_id"] + "','item_name':'" + row["item_name"] + "','price':'" + row["price"] + "','parent_type':'" + row["parent_type"] + "','item_type':'" + row["item_type"] + "'},");
                    }
                    
                }
                sb.Append("]}");
            }
            else
            {
                sb.Append("");
            }
            return sb.ToString();
        }

        public string GetPageCount()
        {
            string sql = "select * from RuncecapeOther";
            DataTable dt = AccessDB.GetDataSet(sql, CommandType.Text, AccessDB.ConnectionString);
            return dt.Rows.Count.ToString();
        }

        public string DleteMsg()
        {
            string id = context.Request["id"].ToString();
            string sql = @"delete from RuncecapeOther where id=" + id + "";
            int row = AccessDB.ExecuteNonQuery(AccessDB.ConnectionString, CommandType.Text, sql);
            return row.ToString();
        }

        public string updatemsg()
        {
            //:game_id,item_name:item_name,price:price,parent_type:parent_type,item_type:item_type,id:id
            try
            {
                string game_id = context.Request["game_id"].ToString().Trim();
                string item_name = context.Request["item_name"].ToString().Trim();
                string price = context.Request["price"].ToString().Trim();
                string parent_type = context.Request["parent_type"].ToString().Trim();
                string item_type = context.Request["item_type"].ToString().Trim();
                string id = context.Request["id"].ToString().Trim();
                string sql = @"update RuncecapeOther set game_id=" + game_id + ",item_name='" + item_name + "',price=" + price + ",parent_type='" + parent_type + "',item_type='" + item_type + "' where id=" + id + "";
                int row = AccessDB.ExecuteNonQuery(AccessDB.ConnectionString, CommandType.Text, sql);
                return row.ToString();
            }
            catch (Exception)
            {

                return "0";
            }
        }
    }
}