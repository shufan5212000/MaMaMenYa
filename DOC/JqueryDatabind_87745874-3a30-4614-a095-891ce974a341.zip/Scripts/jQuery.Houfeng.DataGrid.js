﻿jQuery.fn.extend({
    DataGridClear: function () {
        $(this).RepeaterClear();
    },
    DataGridSetItemClass: function (class1, class2, hoverClass) {
        $(this).RepeaterSetItemClass(class1, class2, hoverClass);
    },
    DataGridSetWidth: function (width) {
        $(this).data('MyTable').width(width);
        $(this).data('TableBodyArea').width(width);
        $(this).data('TableHeadArea').width(width);
    },
    DataGrid: function (width, height, dt) {
        this.each(function () {
            var TableBody = $(this);
            var MyTableId = "houfeng-table-" + TableBody.attr('id');
            if ($(this).data('Drawed')) {

                //TableBody.RepeaterClear();
                TableBody.Repeater(dt);
                TableBody.find('.itemtemplate').slice(1).find('td').css('width', 'auto');
                var tds = TableBody.data('TableHead').find('td');
                tds.each(function () {
                    var td = $(this);
                    $(TableBody.find('tr:first').find('td')[tds.index(td)]).css('width', td.css('width'));
                });
                return;
            }
            //开始渲染表格====================================================
            //

            TableBody.addClass('TableBody');
            TableBody.wrap("<div id='" + MyTableId + "' class='houfeng-table'></div>");
            var MyTable = $('#' + MyTableId);
            TableBody.data('MyTable', MyTable);
            TableBody.before("<table class='TableHead' ></table>");
            var TableHead = MyTable.find(".TableHead");
            TableBody.data('TableHead', TableHead);
            TableBody.wrap('<div class="TableBodyArea"></div>');
            TableHead.wrap("<div class='TableHeadArea' onselectstart='return false;'></div>");
            var TableBodyArea = MyTable.find('.TableBodyArea');
            var TableHeadArea = MyTable.find('.TableHeadArea');
            TableBody.data('TableBodyArea', TableBodyArea);
            TableBody.data('TableHeadArea', TableHeadArea);

            //调整大小.
            TableHead.css('width', '100%');
            TableBody.css('width', '100%');
            MyTable.css('width', width);
            TableBodyArea.css('width', width);
            TableHeadArea.css('width', width);
            TableBody.find('.header').clone().prependTo(TableHead);
            var itemtds = TableBody.find('.itemtemplate').find('td');
            var headtds = TableBody.find('.header').find('td');
            itemtds.each(function () {
                var itemtd = $(this);
                itemtd.css('width', $(headtds[itemtds.index(itemtd)]).css('width'));
            });
            TableBody.find('.header').remove();
            //
            //结束渲染表格====================================================
            //

            TableBodyArea.scroll(function () {
                var ml = 0 - parseInt(TableBodyArea.attr('scrollLeft'));
                TableHead.css('margin-left', ml);
            });
            //

            var tds = TableHead.find('td');
            tds.each(function () {
                var td = $(this);
                var tdcontent = td.html();
                if (td.attr('sort') == 'true') tdcontent = "<span class='sorticon'>↓</span><div class='headtdcontent'>" + tdcontent + "</div>";
                td.html("<div id='" + td.attr('id') + "-resizer' class='resizer'>&nbsp;</div>" + tdcontent);
                //添加排序-----------------------
                var tdindex = tds.index(td);
                var tddatatype = 'string';
                if (td.attr('datatype') != null)
                    tddatatype = td.attr('datatype');
                if (td.attr('sort') == 'true') {
                    var hc = td.find('.headtdcontent');
                    hc.mouseover(function () {
                        td.find('.sorticon').show();
                    });
                    hc.mouseout(function () {
                        td.find('.sorticon').hide();
                    });
                    hc.toggle(function () {
                        td.find('.sorticon').html('↑');
                        sortTable(TableBody, tdindex, tddatatype);
                        $(TableBody).DataGridSetItemClass($(this).data("_class1"), $(this).data("_class2"), $(this).data("_hoverClass"));
                    }, function () {
                        td.find('.sorticon').html('↓');
                        sortTable(TableBody, tdindex, tddatatype);
                        $(TableBody).DataGridSetItemClass($(this).data("_class1"), $(this).data("_class2"), $(this).data("_hoverClass"));
                    });
                }
                //---------------------------------

                var tx = 0;
                var IsMouseDown = false;
                var td_width = parseInt(td.css('width'));
                td.find('.resizer').mousedown(function () {
                    var event = window.event ? window.event : arguments[0];
                    var ex = event.x ? event.x : event.clientX;
                    tx = ex;
                    td_width = parseInt(td.css('width'));
                    IsMouseDown = true;
                });

                $(document).mousemove(function () {
                    if (IsMouseDown) {
                        var event = window.event ? window.event : arguments[0];
                        var ex = event.x ? event.x : event.clientX;
                        var tdw = td_width + (ex - tx);
                        td.css('width', tdw);
                        //
                        return;
                        $(TableBody.find('tr:first').find('td')[tds.index(td)]).css('width', tdw);
                    }
                });

                $(document).mouseup(function () {
                    tx = 0;
                    IsMouseDown = false;

                    var ml = 0 - parseInt(TableBodyArea.attr('scrollLeft'));
                    TableHead.css('margin-left', ml);

                    var tdw = td.css('width');
                    $(TableBody.find('tr:first').find('td')[tds.index(td)]).css('width', tdw);
                });

            });
            //结束为表头添加动作响应----------------------------------------
            //

            //鼠标双击事件
            TableBody.find('td').live('dblclick', function () {
                var td = $(this);
                if (td.attr('editable') == 'true') {

                    var text = td.text();
                    var html = "<input type='text' class='TdEditTextBox' value='" + $.trim(text) + "' />";
                    td.html(html);
                    td.addClass("tdediting");
                    //
                    $(this).find('.TdEditTextBox').focus().focus().focus().focus();
                    $(this).find('.TdEditTextBox').blur(function () {
                        //鼠标双击改变值之后失去焦点激发的事件
                        var val = $(this).val();
                        td.html(val);
                        var id = td.parent().find("input:hidden[class=userid]").val();
                        //此处代码用来取到改行所有的td的值，用于修改数据库
                        /*
                        游戏编号
                        装备名称
                        价格
                        上级目录
                        装备类型 
                        */
                        var game_id = td.parent().find("td:eq(1)").html();
                        var item_name = td.parent().find("td:eq(2)").html();
                        var price = td.parent().find("td:eq(3)").html();
                        var parent_type = td.parent().find("td:eq(4)").html();
                        var item_type = td.parent().find("td:eq(5)").html();
                        $.post("AjaxCallBack.aspx", { act: "updatemsg", game_id: game_id, item_name: item_name, price: price, parent_type: parent_type, item_type: item_type, id: id }, function (data) {
                            if (data == "0") {
                                alert("修改失败，请检查数据类型是否有错！");
                            }
                        });
                        td.removeClass("tdediting");
                    });
                }
            });
            //
            $(this).data('Drawed', true);

            TableBody.DataGrid(width, height, dt);
            //--------------------------------------------------------------
        });
    }
});
//-----------------
//$('table').DataGrid(900,120);