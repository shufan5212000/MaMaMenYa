﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Configuration;
using System.Collections;
using System.Data.OleDb;
using System.Data;

/// <summary>
///AccessDB 的摘要说明
/// </summary>
public static class AccessDB
{
    /// <summary>
    /// 连接字符串
    /// </summary>
    public static readonly string ConnectionString = "provider=Microsoft.Jet.OLEDB.4.0;data Source=|DataDirectory|\\#8000iuuu0site_db1.mdb";
   
    
    private static Hashtable parmCache = Hashtable.Synchronized(new Hashtable());
    /// <summary>
    /// 数据库增,删,改方法
    /// </summary>
    /// <param name="connectionString">连接字符串</param>
    /// <param name="cmdType">Command类型</param>
    /// <param name="cmdText">执行文本</param>
    /// <param name="commandParameters">参数</param>
    /// <returns></returns>
    public static int ExecuteNonQuery(string connectionString, CommandType cmdType, string cmdText, params OleDbParameter[] commandParameters)
    {
        OleDbCommand cmd = new OleDbCommand();
        
        using (OleDbConnection conn = new OleDbConnection(connectionString))
        {
            PrepareCommand(cmd, conn, null, cmdType, cmdText, commandParameters);
            int val = cmd.ExecuteNonQuery();
            cmd.Parameters.Clear();
            return val;
        }
    }

    /// <summary>
    /// 数据库增,删,改方法
    /// </summary>
    /// <param name="connection">连接对象</param>
    /// <param name="cmdType">Command类型</param>
    /// <param name="cmdText">执行文本</param>
    /// <param name="commandParameters">参数</param>
    /// <returns></returns>
    public static int ExecuteNonQuery(OleDbConnection connection, CommandType cmdType, string cmdText, params OleDbParameter[] commandParameters)
    {
        OleDbCommand cmd = new OleDbCommand();
        PrepareCommand(cmd, connection, null, cmdType, cmdText, commandParameters);
        int val = cmd.ExecuteNonQuery();
        cmd.Parameters.Clear();
        return val;
    }

    /// <summary>
    /// 数据库增,删,改方法
    /// </summary>
    /// <param name="trans">事务</param>
    /// <param name="cmdType">Command类型</param>
    /// <param name="cmdText">执行文本</param>
    /// <param name="commandParameters">参数</param>
    /// <returns></returns>
    public static int ExecuteNonQuery(OleDbTransaction trans, CommandType cmdType, string cmdText, params OleDbParameter[] commandParameters)
    {
        OleDbCommand cmd = new OleDbCommand();
        PrepareCommand(cmd, trans.Connection, trans, cmdType, cmdText, commandParameters);
        int val = cmd.ExecuteNonQuery();
        cmd.Parameters.Clear();
        return val;
    }

    /// <summary>
    /// 读取数据
    /// </summary>
    /// <param name="connectionString">连接字符串</param>
    /// <param name="cmdType">Command类型</param>
    /// <param name="cmdText">执行文本</param>
    /// <param name="commandParameters">参数</param>
    /// <returns>OleDbDataReader</returns>
    public static OleDbDataReader ExecuteReader(string connectionString, CommandType cmdType, string cmdText, params OleDbParameter[] commandParameters)
    {
        OleDbCommand cmd = new OleDbCommand();
        OleDbConnection conn = new OleDbConnection(connectionString);
        try
        {
            PrepareCommand(cmd, conn, null, cmdType, cmdText, commandParameters);
            OleDbDataReader rdr = cmd.ExecuteReader(CommandBehavior.CloseConnection);
            cmd.Parameters.Clear();
            return rdr;
        }
        catch
        {
            conn.Close();
            throw;
        }
    }

    /// <summary>
    /// 读取数据
    /// </summary>
    /// <param name="safeSql">执行文本</param>
    /// <param name="cmdType">command类型</param>
    /// <param name="connectionString">连接字符串</param>
    /// <returns>DataTable</returns>
    public static DataTable GetDataSet(string safeSql, CommandType cmdType, string connectionString)
    {
        DataSet ds = new DataSet();
        using (OleDbConnection conn = new OleDbConnection(connectionString))
        {
            OleDbCommand cmd = new OleDbCommand(safeSql, conn);
            
            OleDbDataAdapter da = new OleDbDataAdapter(cmd);
            da.Fill(ds);
            return ds.Tables[0];
        }

    }

    /// <summary>
    /// 读取数据
    /// </summary>
    /// <param name="connectionString">连接字符串</param>
    /// <param name="cmdType">command类型</param>
    /// <param name="sql">执行文本</param>
    /// <param name="values">参数</param>
    /// <returns>DataTable</returns>
    public static DataTable GetDataSet(string connectionString, CommandType cmdType, string sql, params OleDbParameter[] values)
    {
        DataSet ds = new DataSet();
        using (OleDbConnection conn = new OleDbConnection(connectionString))
        {
            OleDbCommand cmd = new OleDbCommand(sql, conn);
            cmd.CommandType = cmdType;
            cmd.Parameters.AddRange(values);
            OleDbDataAdapter da = new OleDbDataAdapter(cmd);
            da.Fill(ds);
            return ds.Tables[0];
        }

    }

    /// <summary>
    /// 获取单个返回值结果
    /// </summary>
    /// <param name="connectionString">连接字符串</param>
    /// <param name="cmdType">command类型</param>
    /// <param name="cmdText">执行文本</param>
    /// <param name="commandParameters">参数</param>
    /// <returns>object对象</returns>
    public static object ExecuteScalar(string connectionString, CommandType cmdType, string cmdText, params OleDbParameter[] commandParameters)
    {
        OleDbCommand cmd = new OleDbCommand();
        using (OleDbConnection connection = new OleDbConnection(connectionString))
        {
            PrepareCommand(cmd, connection, null, cmdType, cmdText, commandParameters);
            object val = cmd.ExecuteScalar();
            cmd.Parameters.Clear();
            return val;
        }
    }

    /// <summary>
    /// 得到单个返回值结果
    /// </summary>
    /// <param name="connection">连接对象</param>
    /// <param name="cmdType">command类型</param>
    /// <param name="cmdText">执行文本</param>
    /// <param name="commandParameters">参数</param>
    /// <returns>object对象</returns>
    public static object ExecuteScalar(OleDbConnection connection, CommandType cmdType, string cmdText, params OleDbParameter[] commandParameters)
    {

        OleDbCommand cmd = new OleDbCommand();
        PrepareCommand(cmd, connection, null, cmdType, cmdText, commandParameters);
        object val = cmd.ExecuteScalar();
        cmd.Parameters.Clear();
        return val;
    }

    public static void CacheParameters(string cacheKey, params OleDbParameter[] commandParameters)
    {
        parmCache[cacheKey] = commandParameters;
    }

    public static OleDbParameter[] GetCachedParameters(string cacheKey)
    {
        OleDbParameter[] cachedParms = (OleDbParameter[])parmCache[cacheKey];
        
        if (cachedParms == null)
            return null;

        OleDbParameter[] clonedParms = new OleDbParameter[cachedParms.Length];

        for (int i = 0, j = cachedParms.Length; i < j; i++)
            clonedParms[i] = (OleDbParameter)((ICloneable)cachedParms[i]).Clone();

        return clonedParms;
    }

    /// <summary>
    /// 处理ADO.NET数据操作对象
    /// </summary>
    /// <param name="cmd">执行对象</param>
    /// <param name="conn">连接对象</param>
    /// <param name="trans">事务对象</param>
    /// <param name="cmdType">command类型</param>
    /// <param name="cmdText">执行文本</param>
    /// <param name="cmdParms">参数</param>
    private static void PrepareCommand(OleDbCommand cmd, OleDbConnection conn, OleDbTransaction trans, CommandType cmdType, string cmdText, OleDbParameter[] cmdParms)
    {

        if (conn.State != ConnectionState.Open)
            conn.Open();

        cmd.Connection = conn;
        cmd.CommandText = cmdText;

        if (trans != null)
            cmd.Transaction = trans;

        cmd.CommandType = cmdType;

        if (cmdParms != null)
        {
            foreach (OleDbParameter parm in cmdParms)
                cmd.Parameters.Add(parm);
        }
    }
}
