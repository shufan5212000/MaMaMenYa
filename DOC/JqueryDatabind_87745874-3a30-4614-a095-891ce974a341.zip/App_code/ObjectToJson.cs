﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Reflection;
//www.51aspx.com
public class ObjectToJson
{
    private Object _Ins;
    /// <summary>
    ///
    /// </summary>
    /// <param name="ins">简单对象</param>
    public ObjectToJson(object ins)
    {
        _Ins = ins;
    }
   
    /// <summary>
    /// 输入Json字符串
    /// </summary>
    /// <returns></returns>
    public string ToJsonString()
    {
        return ToJsonScring(_Ins);
    }
    /// <summary>
    /// 输入Json字符串
    /// </summary>
    /// <param name="ins"></param>
    /// <returns></returns>
    private string ToJsonScring(object ins)
    {
        Type a = ins.GetType();
        StringBuilder sb = new StringBuilder();
        sb.Append("{");
        MemberInfo[] mis = a.GetMembers();
        foreach (MemberInfo mi in mis)
        {
            object mival = GetMemberValue(ins, mi);
            if (mival != null)
            {
                sb.Append("\"");
                sb.Append(mi.Name);
                sb.Append("\":\"");
                string mivaltypename = mival.GetType().Name.ToUpper();
                sb.Append(mival.ToString());
                sb.Append("\",");
            }
        }
        sb.Remove(sb.Length - 1, 1);
        sb.Append("}");
        if (sb.Length > 2)
            return sb.ToString();
        else
            return "";
    }
    /// <summary>
    /// 取一个字段或属性的值.
    /// </summary>
    /// <param name="ins"></param>
    /// <param name="member"></param>
    /// <returns></returns>
    private object GetMemberValue(object ins, MemberInfo member)
    {
        Type a = ins.GetType();
        try
        {
            return a.InvokeMember(member.Name, BindingFlags.GetProperty | BindingFlags.GetField, null, ins, null);
        }
        catch
        {
            return null;
        }
    }
}