﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page 
{
    public string str = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        ObjectToJson json = new ObjectToJson(65464552312);
        string aaa = json.ToJsonString();
        str = "{rows:[";
        str += @"{'id':'1','username':'曹操','usersex':'男','age':'51','address':'许昌','pwd':'123456'},{'id':'2','username':'诸葛亮','usersex':'男','age':'40','address':'南阳','pwd':'123456'},{'id':'3','username':'周瑜','usersex':'男','age':'40','address':'江东','pwd':'123456'},{'id':'4','username':'大乔','usersex':'女','age':'30','address':'江东','pwd':'123456'},{'id':'5','username':'小乔','usersex':'女','age':'28','address':'江东','pwd':'123456'},{'id':'6','username':'曹操','usersex':'男','age':'51','address':'许昌','pwd':'123456'},{'id':'7','username':'诸葛亮','usersex':'男','age':'40','address':'南阳','pwd':'123456'},{'id':'8','username':'周瑜','usersex':'男','age':'40','address':'江东','pwd':'123456'},{'id':'9','username':'大乔','usersex':'女','age':'30','address':'江东','pwd':'123456'},{'id':'10','username':'小乔','usersex':'女','age':'28','address':'江东','pwd':'123456'}";
        str+="]}";   
    }
}